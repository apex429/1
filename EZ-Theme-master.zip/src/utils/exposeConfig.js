﻿
import { SITE_CONFIG } from './baseConfig';


export default function initPageTitle() {
  document.title = SITE_CONFIG.siteName;
} 
